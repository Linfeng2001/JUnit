public class Konto {
	private int bankBalance;
	
	
	public Konto(int KontoStand) {
		this.bankBalance = bankBalance;
	}


	public int getBankBalance() {
		return bankBalance;
	}


	public void setBankBalance(int bankBalance) {
		bankBalance = bankBalance;
	}
	
	
}
